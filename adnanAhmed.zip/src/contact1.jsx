contact = [
  {
    key: "1",
    id: "1",
    name: "Anjali",
    email: "anjali@com",
    password: "1234",
    role: "admin",
  },
  {
    key: "2",
    id: "2",
    name: "Priya",
    email: "teacher@com",
    password: "1234",
    role: "teacher",
  },
  {
    key: "3",
    id: "3",
    name: "mahendra",
    role: "parents",
    email: "mahendra@com",
    password: "1234",
  },
  {
    key: "4",
    id: "4",
    name: "hashmi",
    role: "student",
    email: "mahendra@com",
    password: "1234",
  },
];
export default contact;
