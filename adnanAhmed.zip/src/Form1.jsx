import React, { useState } from "react";
import contactData from "./contact1";

export default function Form() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  function checkEmail(event) {
    setEmail(event.target.value);
  }

  function checkPassword(event) {
    setPassword(event.target.value);
  }

  function check() {
    const user1 = contactData.find(
      (user) => user.email === email && user.password === password
    );
    if (user1) {
      setIsLoggedIn(true);
      console.log("Login successful");
    } else {
      console.log("Login failed");
    }
  }

  return (
    <div className="form">
      <div className="form2">
        <input
          className="input1"
          onChange={checkEmail}
          type="email"
          placeholder="Enter your email"
          value={email}
        />
        <input
          className="input2"
          onChange={checkPassword}
          type="password"
          placeholder="Enter your password"
          value={password}
        />

        <button className="btn" onClick={check}>
          Login
        </button>

        {isLoggedIn && <p>Login successful!</p>}
        {!isLoggedIn && <p>login failed</p>}
      </div>
    </div>
  );
}
/*function check() {
    const user1 = contactData.find(
      (user) => user.email === email && user.password === password
    );
    if (user1) {
      setIsLoggedIn(true);
      console.log("Login successful");
    } else {
      console.log("Login failed");
    }
  } */
