import "./styles.css";
import Form from "./Form1";

export default function App() {
  return (
    <div className="App">
      <div className="secondBox">
        <div className="schoolName">
          <h1> Ekattor7</h1>
        </div>
        <div className="extra">
          <div className="sign">
            <h2 className="header"> Sign in</h2>
            <p>Enter your email address and password to access account</p>
          </div>
          <Form />

          <p className="email">Email</p>
          <p className="password">password</p>
        </div>
        <p className="details">forgot your logging details</p>
      </div>
    </div>
  );
}
